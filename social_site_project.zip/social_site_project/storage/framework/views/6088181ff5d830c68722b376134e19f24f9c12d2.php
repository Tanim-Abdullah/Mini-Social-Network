<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <center>
    	<form class="form-horizontal" action="<?php echo e(route('file-upload')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(@csrf_field()); ?>

            <strong>Select Category</strong><br>
    		<input type="radio" id="weeding" name="category" checked="checked" value="weeding">
            <label for="weeding">Weeding</label><br>
            <input type="radio" id="family" name="category" value="family">
            <label for="family">Family</label><br>
            <input type="radio" id="corporate" name="category" value="corporate">
            <label for="corporate">Corporate</label><br>
            <input type="radio" id="product" name="category" value="product">
            <label for="product">Product</label><br>
            <strong>Select photo</strong>
            <input type="file" accept="image/*" name="photo[]" placeholder="Enter your Product title" class="form-control" required multiple><br>
            <br><br>
            <input type="submit">
    	</form>
    </center>
</body>
</html><?php /**PATH H:\webtech\laravel intern projects\login\resources\views/dashboard/image.blade.php ENDPATH**/ ?>